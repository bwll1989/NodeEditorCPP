/**
 * @file NDVServerDataModel.hpp
 * @brief NDV Server 薄壳：转发指令到全局 NDVController，并输出客户端列表
 *
 * 不再自建 TcpServer；与 Player 共享同一监听实例（默认 9008）。
 */
#pragma once

#include <QDateTime>
#include <QTimer>

#include "Common/BaseClass/AbstractDelegateModel.h"
#include "Common/DataTypes/NodeDataList.hpp"
#include "Common/Devices/NDVController/NDVController.h"
#include "Common/Devices/StatusContainer/GlobalEventBus.hpp"

using QtNodes::ConnectionPolicy;
using QtNodes::NodeData;
using QtNodes::NodeDataType;
using QtNodes::NodeDelegateModel;
using QtNodes::PortIndex;
using QtNodes::PortType;
using namespace NodeDataTypes;

namespace Nodes
{
    class NDVServerDataModel : public AbstractDelegateModel
    {
        Q_OBJECT
        Q_PROPERTY(int port READ port CONSTANT)
        Q_PROPERTY(bool listening READ listening NOTIFY listeningChanged)

    public:
        NDVServerDataModel()
        {
            InPortCount = 1;
            OutPortCount = 1;
            CaptionVisible = true;
            Caption = QStringLiteral("NDV Server");
            WidgetEmbeddable = false;
            Resizable = false;
            PortEditable = true;

            statusData = std::make_shared<VariableData>();
            m_controller = NDVController::getInstance();

            connect(m_controller, &NDVController::clientListChanged,
                    this, &NDVServerDataModel::publishClientStatus);
            connect(m_controller, &NDVController::clientStatusChanged,
                    this, [this](int, const NDVClientInfo &) {
                        publishClientStatus();
                    });
            connect(m_controller, &NDVController::listeningChanged,
                    this, [this](bool ready) {
                        Q_EMIT listeningChanged(ready);
                        publishClientStatus();
                    });

            // 定期刷新输出，便于监控
            m_refreshTimer = new QTimer(this);
            m_refreshTimer->setInterval(2000);
            connect(m_refreshTimer, &QTimer::timeout, this, &NDVServerDataModel::publishClientStatus);
            m_refreshTimer->start();

            publishClientStatus();
        }

        ~NDVServerDataModel() override
        {
            if (m_refreshTimer) {
                m_refreshTimer->stop();
                disconnect(m_refreshTimer, nullptr, this, nullptr);
            }
            // 对齐 ArtnetOut：只断开信号，不销毁全局单例
            if (m_controller) {
                disconnect(m_controller, nullptr, this, nullptr);
                m_controller = nullptr;
            }
        }

        QString portCaption(PortType portType, PortIndex portIndex) const override
        {
            if (portType == PortType::In) {
                return QStringLiteral("PLAYER %1").arg(portIndex);
            }
            if (portType == PortType::Out) {
                return QStringLiteral("CLIENT_STATUS");
            }
            return {};
        }

        NodeDataType dataType(PortType, PortIndex) const override
        {
            return VariableData().type();
        }

        std::shared_ptr<NodeData> outData(PortIndex const) override
        {
            return statusData;
        }

        void setInData(std::shared_ptr<NodeData> data, PortIndex const) override
        {
            if (!data || !m_controller) {
                return;
            }
            auto variableData = std::dynamic_pointer_cast<VariableData>(data);
            if (!variableData) {
                return;
            }

            const QVariantMap commandMap = variableData->getMap();
            const QString commandType = commandMap.value(QStringLiteral("type")).toString();
            const int fileIndex = commandMap.value(QStringLiteral("fileIndex"), 0).toInt();
            const int targetId = commandMap.value(QStringLiteral("targetId"), 0).toInt();
            if (commandType.isEmpty()) {
                return;
            }
            m_controller->sendCommand(commandType, fileIndex, targetId);
        }

        QJsonObject save() const override
        {
            QJsonObject address;
            address[QStringLiteral("Port")] = NDVController::FIXED_PORT;
            QJsonObject modelJson = NodeDelegateModel::save();
            modelJson[QStringLiteral("Address")] = address;
            return modelJson;
        }

        void load(const QJsonObject &p) override
        {
            NodeDelegateModel::load(p);
            publishClientStatus();
        }

        ConnectionPolicy portConnectionPolicy(PortType portType, PortIndex) const override
        {
            return (portType == PortType::In || portType == PortType::Out)
                ? ConnectionPolicy::Many
                : ConnectionPolicy::One;
        }

        int port() const { return NDVController::FIXED_PORT; }
        bool listening() const
        {
            return m_controller && m_controller->isListening();
        }

    Q_SIGNALS:
        void listeningChanged(bool ready);

    private slots:
        void publishClientStatus()
        {
            if (!m_controller) {
                return;
            }

            statusData = std::make_shared<VariableData>();
            QVariantMap clientsMap;
            const QList<NDVClientInfo> list = m_controller->clients();
            for (const NDVClientInfo &info : list) {
                QVariantMap clientInfo;
                clientInfo.insert(QStringLiteral("ip"), info.ipAddress);
                clientInfo.insert(QStringLiteral("id"), info.deviceId);
                clientInfo.insert(QStringLiteral("online"), info.online);
                clientInfo.insert(QStringLiteral("status"), info.state);
                clientInfo.insert(QStringLiteral("lastSeen"), info.lastSeen.toString(Qt::ISODate));
                clientInfo.insert(QStringLiteral("lastHandshake"),
                                  info.lastHandshake.toString(Qt::ISODate));
                clientsMap.insert(QString::number(info.deviceId), clientInfo);
            }

            statusData->insert(QStringLiteral("ConnectedClients"), clientsMap);
            statusData->insert(QStringLiteral("ClientCount"), list.size());
            statusData->insert(QStringLiteral("Listening"), m_controller->isListening());
            statusData->insert(QStringLiteral("Port"), NDVController::FIXED_PORT);
            statusData->insert(QStringLiteral("LastUpdate"),
                               QDateTime::currentDateTime().toString(Qt::ISODate));
            Q_EMIT dataUpdated(0);
        }

    private:
        std::shared_ptr<VariableData> statusData;
        NDVController *m_controller = nullptr;
        QTimer *m_refreshTimer = nullptr;
    };
}
