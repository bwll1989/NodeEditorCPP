# NDV Server

## 1. 节点说明

**薄壳监控/兼容节点**：自身不再创建 TCP 服务，而是 `acquire` 全局 **NDVController**（固定端口 **9008**）。  
用于输出全部客户端状态，并兼容旧图中「Player COMMAND → Server PLAYER」的连线方式。

新工程推荐直接使用 **NDV Player**（按 ID 直控），无需本节点。

## 2. 端口

### 输入

| 端口 | 说明 |
|------|------|
| PLAYER 0 … | 兼容旧指令包（`type` / `fileIndex` / `targetId`），转发到 Controller |

### 输出

| 端口 | 说明 |
|------|------|
| CLIENT_STATUS | `ConnectedClients`、`ClientCount`、`Listening`、`Port` |

## 3. 行为

- 监听由 NDVController 统一管理（与 Player 共享）
- 握手 / 心跳 / 状态解析均在 Controller 内完成
- 本节点只做转发与列表展示

## 4. 迁移说明

旧流程：`NDV Player (COMMAND) → NDV Server (PLAYER)`  
新流程：`NDV Player` 直接控设备；Server 可选保留作总览。
