/*! @plugin {
    "name": "Scripts Template",
    "description": "脚本模板",
    "version": "1.0.0",
    "author": "吴斌",
    "category": "Controls",
    "embeddable": true,
    "resizable": true,
    "portEditable": false,
    "inputs":1,
    "outputs":1
} */

var slider1;
function initInterface() {
    // 在这里编写初始化界面的代码
    // 例如：创建按钮、文本框等
}
function inputEventHandler(index){
    // 处理输入事件
    console.log(index)
}
